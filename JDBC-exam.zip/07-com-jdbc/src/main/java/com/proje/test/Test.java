package com.proje.test;

import com.proje.Service.CategoryService;
import com.proje.Service.ProductService;
import com.proje.Service.UserService;
import com.proje.model.Brand;
import com.proje.model.Category;
import com.proje.model.Product;
import com.proje.model.User;

import java.sql.Date;
import java.util.List;

import com.proje.Service.BrandService;
import com.proje.serviceImplement.BrandServiceImplement;
import com.proje.serviceImplement.CategoryServiceImplement;
import com.proje.serviceImplement.ProductServiceImplement;
import com.proje.serviceImplement.UserServiceImplement;

public class Test {
public static void main(String[] args) {
	
	BrandService brandService =new BrandServiceImplement();
	UserService userService=new UserServiceImplement();
	ProductService productService =new ProductServiceImplement();
	CategoryService categoryService=new CategoryServiceImplement();
	
//User user =new User(1, "suleyman", "karacavus", new Date(new java.util.Date().getTime()), "suleymankaracavus", null);
//	userService.saveUser(user);
//	Product product= new Product(1, "Asus", 1800, 1, new java.util.Date(), null, null, null);
	
		
}}
