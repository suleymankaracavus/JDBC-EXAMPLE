package com.proje.model.queries;

public class CategoryQuery {
	public static final String findCategoryByIdQuery="Select*From category where categoryId=?";
	public static final String findCategoriesQuery="Select*from category";
	
	

}
