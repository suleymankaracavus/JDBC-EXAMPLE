package com.proje.model.queries;

public class BrandQuery {
	public static final String findBrandByIdQueryId="Select* From brand where brandId=?";
	public static final String findBrands="Select*from brand";
}
