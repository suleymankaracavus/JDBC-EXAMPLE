package com.proje.Repository;

import java.util.List;

import com.proje.model.Brand;

public interface BrandRepository {
	

	Brand findBrandById(int id);
	Brand saveBrand(Brand brand);
	
	List<Brand> findBrands();

	


}
