package com.proje.Service;

import java.util.List;

import com.proje.model.Category;

public interface CategoryService {
	
	
	List<Category> findCategories();
	Category findCategoryById(int id);

}
